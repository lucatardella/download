## INFERENZA STATISTICA A.A. 2025/2026

## LAB 01 - Quesiti finali di verifica:

## 0. Invoca il comando che fornisce la pagina di help on-line che riguarda la funzione sample(...)

## 1. Crea dati osservati secondo il modello di un'urna. In particolare, genera 1000 dati osservati da una distribuzione di Bernoulli (dicotomica a valori 0=insuccesso o 1=successo) di parametro theta=0.2. Ricorda che in questo modello il parametro theta rappresenta la probabilità di ottenere un successo.

##          θ = Pr{X_i=1 ;θ}


## 2. Fai in modo che i dati generati "a caso" siano _riproducibili_ impostando un "seme di generazione" (di partenza) pari ad 55555

## 3. Conta i successi e gli insuccessi

## 4. Se calcoli la media dei valori estratti con la funzione mean(...) come interpreti il risultato che ottieni?

## 5. Verifica quanti dati sono a disposizione nell'oggetto velocita.vento.11 che trovi tra gli oggetti dell'area di lavoro salvata nel file "esempi-dati-reali.RData"

load("esempi-dati-reali.RData")
ls()

## 6. Traccia un istogramma della distribuzione della velocità del vento registrate nell'oggetto velocita_vento_11

## 7. Spiega come cambia l'interpretazione dell'istogramma riprodotto quando si utilizza l'argomento freq=FALSE

## 8. Spiega come cambia l'interpretazione dell'istogramma riprodotto quando si utilizza l'argomento prob=TRUE

