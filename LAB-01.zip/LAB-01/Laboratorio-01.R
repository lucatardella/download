## LAB #01
## Laboratorio di Inferenza Statistica - LT+CM
## a.a. 2025/2026

##### Parole chiave: Creare, riconoscere, distruggere, trasformare, acquisire dati.{-}

### Sommario:{-} ----

# Lo studente del secondo anno del corso di studi di laurea triennale L-41 dovrebbe già conoscere le nozioni fondamentali del linguaggio di R e delle modalità di utilizzo di tale linguaggio mediante l'ambiente di sviluppo integrato (IDE) denominato RStudio. Pertanto buona parte di questo laboratorio dovrebbe risultare, in parte, come un ripasso di nozioni già acquisite. I software R ed RStudio devono essere preventivamente installati nel proprio computer per poter seguire il Laboratorio di Inferenza.

# Nel primo laboratorio, con la filosofia del *learning-by-doing* ci avviciniamo ad R, attraverso RStudio, imparando a

# 1. scaricare il file compresso predisposto come "progetto" `LAB-01.zip`; comprendere la nozione di directory di lavoro (working directory) e imparare a stabilire quale è ed eventualmente a modificarla;
# 2. Creare un oggetto, visualizzare il contenuto di un oggetto, "modificare"[ricreare] oggetti;
# 3. Riconoscere le diverse tipologie e proprietà di un oggetto (mode, class, ...) in particolare gli oggetti con mode "numeric" e "function";
# 4. Modificare gli oggetti (in tutto o in parte);
# 5. Rimuovere gli oggetti;
# 6. Usare le funzioni di R: regole generali, sintassi, argomenti e loro nomi, valori di default, aiuto on line (help),  composizione/piping;
# 7. Costruire nuove funzioni con R: funzioni semplici con: nessun argomento, un argomento, più argomenti; valori di default degli argomenti di una funzione;
# 8. Creare tanti numeri in sequenza con un certo criterio oppure ... **a caso**: introduzione all'uso di alcune funzioni relative alla generazione/simulazione di numeri casuali ed esperimenti di estrazione casuale da un'urna: sample(...) e rnorm(...);
# 9. Utilizzare dati esterni memorizzati su file: lettura e scrittura di file di testo (.txt, formato ASCII) oppure dati nel formato .RData (workspace);

# Un ingrediente fondamentale per una fruizione adeguata dell'attività di laboratorio è l'aggiunta di commenti/appunti che ciascuno studente ritiene utile per una migliore comprensione degli esempi e dei concetti sottostanti e anche per la produzione personalizzata di altri esempi. I commenti si aggiungono nel file con estensione .R facendo precedere il commento con il carattere #. Tutto ciò che è scritto dopo il carattere # non viene interpretato da R come codice/istruzione.

# E' anche molto importante che durante il laboratorio lo studente riesca ad aggiungere alle istruzioni già predisposte tutte quelle che verranno editate dal docente 'a braccio' durante le spiegazioni. Nel caso si incontrassero difficoltà lo studente si potrà comunque avvalere della copia dello script R del docente che verrà salvata alla fine del laboratorio.

# Il comando seguente consente di rimuovere tutti gli oggetti eventualmente presenti 
# nella memoria (nello specifico, lo spazio di memoria chiamato 'Global environment')
# prima di iniziare le elaborazioni della sessione di lavoro.

rm(list=ls()) # se particolarmente preziosi, salva gli oggetti in un'area di lavoro prima di rimuoverli!!!

### Imparare a creare/usare la cartella di un progetto  ----

getwd()
dir()
directory_di_partenza <- getwd()
dir("~") # directory dell'utente nel sistema operativo
setwd("~") # modificato la directory di riferimento per R da ora in poi
dir()
getwd()

# Per impostare 'a mano' la directory di lavoro desiderata, 
# adatta il seguente comando commentato al percorso in cui si trova 
# la cartella LAB-01 sul tuo computer! 
# setwd("/Users/cristina/Dropbox/Laboratorio_Inferenza/LAB-01")

getwd()

# Come possiamo fare per ripristinare la directory iniziale?
# ...
# Riempite voi i puntini e verificate che sia avvenuto quello che intendevamo

# Ora vediamo come evitare problemi e semplificare il nostro lavoro
# avvalendoci di
# - un "Progetto" di RStudio denominato LAB-01
# - della cartella di Progetto denominata LAB-01
# - del file LAB-01.Rproj inserita all'interno della cartella

# Scaricate la cartella compressa e decomprimetela.
# Go to Project menu (on the topright corner)
# Select New Project
# Choose one of the following:
# - New Directory (create a new folder for the project).
# - Existing Directory (use an existing folder).
# Click Create Project.
#
### - Creare oggetti di diversa 'natura' ovvero di diverso "modo" o storage mode ----

numero_volte <-  2
numero_intero <-  3L
numero_in_precisione_doppia <- 1.73
(altro_numero_in_precisione_doppia <- pi)
stringa_per_voi <- "Benvenuti"
altra_stringa <- "benvenuti"
elemento_logico <- TRUE
altro_logico <- F
altro_logico_falso <- FALSE

# notiamo che è cambiato lo stato dell'ambiente (di memoria) che contiene
# tutti gli oggetti che abbiamo creato finora ...

ls()

# ... e che possiamo usare d'ora in poi
numero_intero
numero_intero*numero_intero
stringa_per_voi==altra_stringa

### - Riconoscere le diverse tipologie e proprietà di un oggetto ----

# verifichiamo le proprietà fondamentali degli oggetti in R
# iniziamo dalle proprietà fondamentali chiamate il modo e il tipo
# che ci informano sulla natura dell'informazione contenuta nell'oggetto

mode(numero_intero)
mode(numero_in_precisione_doppia)
typeof(numero_intero)
typeof(numero_in_precisione_doppia)
class(numero_intero)
class(numero_in_precisione_doppia)

# ... proseguite voi

ls()

# abbiamo anche oggetti che, pur non essendo nell'ambiente di memoria
# corrispondente agli oggetti creati (oppure caricati)
# nella sessione di lavoro corrente
# ambiente detto Global Enviroment o .GlobalEnv,
# possono essere usati ed "esplorati"

search()

mode(pi)
mode(ls)
mode(c)

# ora creiamo altri oggetti un po' più ricchi di informazione

vettore_pochi_numeri <- c(48,28,24)
mode(vettore_pochi_numeri)
class(vettore_pochi_numeri)
length(vettore_pochi_numeri)

# ora creiamo un po' di vettori con tanti numeri
# vettore_cento_numeri <- c(1,2, .....) come si fa?
# help(seq) e scorciatoia
vettore_countdown <- 10:1
vettore_countdown
length(vettore_countdown)
print(vettore_countdown)

saluto <- "ciao"
saluti <- c("buongionrno","buonasera","buonanotte")
mode(saluti)
length(saluti)

logici_alternati <- c(T,F,T,F)
logici_a_coppie <- c(TRUE,TRUE,FALSE,FALSE)

!(logici_alternati) # Negazione logica

df_NOT <- data.frame(operazione="!",Logico1=logici_alternati,uguale="=",risultato=!logici_alternati)
df_NOT


(logici_alternati&logici_a_coppie) # Intersezione logica

df_AND <- data.frame(Logico1=logici_alternati,
                     operazione="&",
                     Logico2=logici_a_coppie,
                     uguale="=",
                     risultato=logici_alternati&logici_a_coppie)
df_AND
?print.data.frame
print(df_AND)
print(df_AND,row.names=FALSE)

(logici_alternati|logici_a_coppie) # Unione logica

df_OR <- data.frame(Logico1=logici_alternati,operazione="|",Logico2=logici_a_coppie,uguale="=",risultato=logici_alternati|logici_a_coppie)
df_OR

# (D1) ci siamo mai chiesti quando incontriamo
# gli elementi logici come risultato di elaborazioni
# (D2) ci siamo mai chiesti a cosa servono gli elementi logici in R?
# ..... (da riempire)

# verifica della diversa 'natura' ovvero del diverso modo (storage mode) degli oggetti creati

mode(numero_volte)
mode(vettore_pochi_numeri)
mode(saluti)
mode(logici_alternati)
mode(c)

typeof(numero_volte)
typeof(vettore_pochi_numeri)
typeof(saluti)
typeof(logici_alternati)
typeof(c) # primitive function written in C

mode(df_AND)
typeof(df_AND)
class(df_AND)

# In R tutti gli oggetti di modo numerico ("numeric") e stringa ("character") sono concepiti come vettori: l'unica differenza tra uno scalare e un vettore in R è la lunghezza del vettore. In altre parole uno scalare è semplicemente un vettore di lunghezza 1.

length(vettore_pochi_numeri)
str(vettore_pochi_numeri)

# talvolta esistono anche oggetti un po' strani per contenuto e natura
vuoto <- c()
length(vuoto)
mode(vuoto)
str(vuoto)

vuoto_numerico <- vector(mode="numeric",length=0)
vuoto_numerico
vuoto_stringa <- vector(mode="character",length=0)
vuoto_stringa

### - Modificare gli oggetti (in tutto o in parte) ----

# I modi in cui si possono modificare gli oggetti sono sostanzialmente 2.
# L'importante è capire che molto spesso (quasi sempre) quando applichiamo
# funzioni ad uno o più oggetti quello che facciamo è usare il loro contenuto
# e quasi mai lo modifichiamo.

# Ad esempio il seguente comando non modifica l'oggetto scalare
numero_volte+2
numero_volte
# Analogamente il seguente comando non modifica l'oggetto vettore
sum(vettore_pochi_numeri)
vettore_pochi_numeri
# e ancora l'esecuzione del seguente comando non modifica l'oggetto stringa_per_voi
toupper(stringa_per_voi)
stringa_per_voi

# Per modificare il contenuto dell'oggetto denominato scalare dobbiamo
# usare un'espressione che assegna nuovo contenuto
# ad un oggetto che ha lo stesso nome dell'oggetto da "modificare"
numero_volte <- numero_volte+2
numero_volte
stringa_per_voi <- toupper(stringa_per_voi)
stringa_per_voi

# Un altro esempio di modalità con cui riusciamo a modificare un oggetto è
# attraverso la riassegnazione del contenuto di una sua parte.

vettore_pochi_numeri
# Innaniztutto accediamo al secondo elemento del vettore ...
vettore_pochi_numeri[2]
# ... modifichiamo il secondo elemento del vettore
# (e quindi modifichaimo il vettore)
# anche qui con una nuova assegnazione di contenuto, come segue
vettore_pochi_numeri[2] <- 0
vettore_pochi_numeri

# Nella prossima sezione impareremo lavorare con oggetti un po' più complessi
# sia dal punto di vista della loro natura che dal punto di vista della sintassi
# per la loro creazione.
# Iniziamo quindi a parlare degli oggetti di modo "function" detti anche funzioni.


### - Introduzione alle funzioni in R. ----

# Una tipologia di oggetti molto speciale: il modo "function".

#### - Far funzionare le funzioni. ----
# Iniziamo con notare la differenza tra le due seguenti espressioni da eseguire singolarmente
ls()
ls
# commenti? sapresti spiegare la differenza
# tra i due risultati appena ottenuti?
?ls

# sapresti prevedere i due risultati dell'esecuzione
# delle seguenti linee di codice?
mode(ls())
mode(ls)

args(ls)

# Le funzioni in R: argomenti e loro nomi, valori di default, aiuto on line (help),

args(round)
?round

round(pi,2)
round(2,pi)
round(digits=2,x=pi)

# Note a margine:
# - per scrivere un commento si inizia la linea con il carattere # (cancelletto)
# - per chiedere aiuto on-line sulla sintassi e l'utilizzo di una funzione si usa o il punto interrogativo prima del nome della funzione oppure la funzione help(...) inserendo il nome della funzione al posto di ... I seguenti comandi sono esempi di utilizzo dell'help on-line


# Le funzioni in R: composizione/piping;

somma <- sum(vettore_pochi_numeri)
somma
log(somma,base=10)

log(sum(vettore_pochi_numeri),base=100)

# sapresti prevedere il risultato dell'esecuzione
# della linea di codice che segue?
exp(log(sum(vettore_pochi_numeri)))

#### - Creare nuove funzioni. ----

# Creazione di funzioni di uno o più argomenti

# (TRA PARENTESI SPECIFICO SE/QUANTI/QUALI/COME SI CHIAMANO GLI ARGOMENTI DELLA FUNZIONE)
saluta  <- function(){
  print("CIAO")
}

saluta()

area_cerchio <- function(x){
  area <- x*x*pi
  return(area)
}

area_cerchio(1)
pi

# area_cerchio() # problema!!

area_cerchio()

area_cerchio <- function(x=1){
  area <- x*x*pi
  return(area)
}

# cosa restituisce?
area_cerchio()
# cosa restituisce?
area_cerchio

### - Rimuovere gli oggetti; ----

# ricontrolliamo quanti oggetti abbiamo e identifichiamone
# qualcuno poco utile che possiamo rimuovere
ls()
rm("saluta")
ls()
rm("stringa_per_voi","vettore_pochi_numeri")
rm(list=ls())
ls()
# ahhhhhh .... ho perso tutti gli oggetti che avevo creato!!!!
# Purtroppo non posso annullare l'operazione di rimozione.
# E ora come proseguiamo?
# Sapresti ricrearli tutti in pochi secondi grazie ad RStudio?

### - Creare tanti numeri, ma soprattutto ... crearli a caso!!  ----

# .... con criterio oppure ... a caso!!

tante_realizzazioni <- rnorm(n=1000000)
hist(tante_realizzazioni)
tante_realizzazioni <- rnorm(n=1000000)
hist(tante_realizzazioni,prob=TRUE)
lines(density(tante_realizzazioni))
curve(dnorm(x),add=TRUE,col="red",lwd=3)

set.seed(123)
rnorm(1)
vettore_2 <- rnorm(20)
vettore_2

hist(rnorm(2000))

# uno studente dice che ...
# per creare una realizzazione di 20 numeri
# provenienti da un vettore casuale
# a componenti indipendenti
# e identicamente distribuite
# ciascuna con media=3 e varianza=4

# .....

# Generazione di dati a caso secondo il modello normale
numeri_a_caso <- rnorm(10000)
?rnorm
#
# Rappresentazione grafica della distribuzione di dati generati a caso secondo il modello normale (si parla di generazione di numeri *pseudo-casuali*)
#
hist(numeri_a_caso)
#
# Divertiti a provare diversi numeri in input!
# Ad esempio prova a vedere cosa succede con
# argomento uguale a 1000 oppure 100, 10  o addirittura 1 ...
# e poi esprimi i tuoi commenti su quello che vedi rappresentato

# Generazione di dati a caso secondo il modello dell'urna
#
# [prima di iniziare provate ad invocare l'aiuto in linea del comando/funzione sample(...) digitando help(sample) o ?sample]

?sample

theta_star <- 0.9

sample(x=c(0,1),replace=TRUE,size=1,prob=c(1-theta_star,theta_star))

urna <- sample(x=c("blue","RED"),size=3000,replace=T)
urna

# Per generare dei numeri pseudo-casuali in R in modo 'controllato' è possibile stabilire un comune punto di partenza anche detto 'seme di generazione'

set.seed(123)
urna <- sample(x=c("blue","RED"),size=3,replace=T)
urna

### - Utilizzo di dati esterni memorizzati su file ----

# lettura e scrittura di file di testo (.txt, .csv formato ASCII)
# oppure
# lettura e scrittura di file formato .RData (workspace);

# Lettura di un file (ASCII) di dati numerici. Osservare il contenuto del file prima di eseguire il comando

velocita <- scan("velo.txt")
velocita
str(velocita)
length(velocita)
mean(velocita)

# Scrittura di un file (ASCII) contenente i dati numerici di un vettore
write(velocita,file="velo2.txt")
write.table(data.frame(veloc=velocita),file="velo3.txt")
write.table(data.frame(veloc=velocita),file="velo3.txt",
            row.names=FALSE,quote=FALSE)

# Le funzioni in realtà più usati per importare ed esportare dati sono:
# read.csv(...)
# ed i comandi della famiglia read.___
# write.csv(...)
# ed i comandi della famiglia write.___

# E' presto per approfondire questi due tipi di funzioni. Li vedremo all'opera nei successivi laboratori.

# nel frattempo cercate di capire la differenza tra
# [A] l'importazione di dati con il comando load(...) e ...
# {per capire load(...) mandiamo in esecuzione le seguenti tre linee di codice}

ls()
load("esempi-dati-reali.RData")
ls()

mode(venti_laguna)
class(venti_laguna)
str(venti_laguna)

# {a cosa è servito il comando ls() prima e dopo del comando load("esempi-dati-reali.RData")?}

# ... e il comando
dati_velocita <- read.table("velo.txt",header=FALSE)
#
# usa quindi
str(velocita)
#
#
str(dati_velocita)
#
# verificate il modo dei due oggetti `velocita_vento_11` e `dati_velocita`

# così potete capire il risultato della seguente funzione
identical(velocita,dati_velocita)

# come posso verificare che i due oggenti contengono comunque gli stessi dati numerici?

# ....

# Suggerimento: in effetti per estrarre i dati di una colonna di un data.frame come dati_velocita è possibile usare il $ seguito dal nome della variabile

dati_velocita$V1

# Ripeto la domanda: come posso verificare che i due oggenti contengono comunque gli stessi dati numerici?

# due possibili risposte:

# usando identical(...)
# usando "=="
# (per questo specifico caso) usando plot(...)

